rm -r DatosDescarga-UTF8
rm DatosDescarga-UTF8.zip
wget https://github.com/aragonopendata/local-data-aragopedia/raw/master/data/resource/DatosDescarga-UTF8.zip
unzip -o DatosDescarga-UTF8.zip
rm -r metadata
./GenerateRDF.sh
rm -r data/dump/datacube/*
mv dump/zip/* data/dump/datacube/
cd app/KBManager
java -cp target/kbmanager-0.0.1-SNAPSHOT.jar fr.eurecom.threecixty.kbmanager.cli.Main deploy -c datacube -f
cd ../..
