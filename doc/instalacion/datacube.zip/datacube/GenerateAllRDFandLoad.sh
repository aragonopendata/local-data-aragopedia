rm -r DatosDescarga-UTF8
rm -r config
rm DatosDescarga-UTF8.zip
wget https://github.com/aragonopendata/local-data-aragopedia/raw/master/data/resource/DatosDescarga-UTF8.zip
unzip -o DatosDescarga-UTF8.zip
java -Dfile.encoding=UTF8 -jar DataCube.jar data DatosDescarga-UTF8 dump config InformesEstadisticaLocal-URLs.csv /var/lib/tomcat7/webapps/standalone/specs/iaest.ttl
rm -r data/dump/datacube/*
mv dump/zip/* data/dump/datacube/
cd app/KBManager
java -cp target/kbmanager-0.0.1-SNAPSHOT.jar fr.eurecom.threecixty.kbmanager.cli.Main deploy -c datacube -f
cd ../..
cp -rf dump/DatosTTL/* local-data-aragopedia/data/dump/DatosTTL/
cp -rf hashcode.csv local-data-aragopedia/data/resource/
cp -rf config/* local-data-aragopedia/data/resource/DatosDescarga-UTF8
cd local-data-aragopedia
git add .
git commit -m "Prueba hugo $(date)"
git push origin master

