rm -r DatosDescarga-UTF8
rm DatosDescarga-UTF8.zip
wget https://github.com/aragonopendata/local-data-aragopedia/raw/master/data/resource/DatosDescarga-UTF8.zip
unzip -o DatosDescarga-UTF8.zip
rm -r metadata
java -jar DataCube.jar data DatosDescarga-UTF8 dump metadata InformesEstadisticaLocal-URLs.csv
rm -r data/dump/datacube/*
mv dump/zip/* data/dump/datacube/
cd app/KBManager
java -cp target/kbmanager-0.0.1-SNAPSHOT.jar fr.eurecom.threecixty.kbmanager.cli.Main deploy -c datacube -f
cd ../..
cp -rf dump/DatosTTL/* local-data-aragopedia/data/dump/DatosTTL/
cp -rf hashcode.csv local-data-aragopedia/data/resource/
cd local-data-aragopedia
git config --global credential.helper cache
git config --global user.name "hlafuente"
git config --global user.email "hlafuente@localidata.com"
git add .
git commit -m "Actualización  automatica $(date)"
git push origin master

