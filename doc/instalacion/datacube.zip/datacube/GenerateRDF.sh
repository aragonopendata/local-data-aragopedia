java -jar DataCube.jar data DatosDescarga-UTF8 dump metadata
