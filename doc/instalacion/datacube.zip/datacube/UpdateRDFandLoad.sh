cd ~/datacube 
rm -r DatosDescarga-UTF8
rm -r config
rm -r DimensionesCuradas
rm DimensionesCuradas.zip
wget https://github.com/aragonopendata/local-data-aragopedia/raw/master/data/resource/DimensionesCuradas.zip
unzip -o DimensionesCuradas.zip
rm InformesEstadisticaLocal-URLs.csv
wget https://github.com/aragonopendata/local-data-aragopedia/raw/master/src/00_select-reports/InformesEstadisticaLocal-URLs.csv
rm -r metadata
java -jar DataCube.jar update InformesEstadisticaLocal-URLs.csv DatosDescarga-UTF8 DimensionesCuradas/codelists config dump DimensionesCuradas/medidas-curadas
rm -r data/dump/datacube/*
mv dump/zip/* data/dump/datacube/
cd app/KBManager
java -cp target/kbmanager-0.0.1-SNAPSHOT.jar fr.eurecom.threecixty.kbmanager.cli.Main deploy -c datacube -f
cd ../..
