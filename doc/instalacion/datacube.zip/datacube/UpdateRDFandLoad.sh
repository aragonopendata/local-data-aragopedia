cd ~/datacube 
rm -r DatosDescarga-UTF8
rm -r config
java -jar DataCube.jar update InformesEstadisticaLocal-URLs.csv DatosDescarga-UTF8 config dump /var/lib/tomcat7/webapps/standalone/specs/iaest.ttl
rm -r data/dump/datacube/*
mv dump/zip/* data/dump/datacube/
cd app/KBManager
java -cp target/kbmanager-0.0.1-SNAPSHOT.jar fr.eurecom.threecixty.kbmanager.cli.Main deploy -c datacube -f
cd ../..
cp -rf dump/DatosTTL/* local-data-aragopedia/data/dump/DatosTTL/
cp -rf hashcode.csv local-data-aragopedia/data/resource/
cd local-data-aragopedia
git add .
git commit -m "Actualización  automatica $(date)"
git push origin master
